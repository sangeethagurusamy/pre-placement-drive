package com.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.QuestionDAO;
import com.spring.domain.Question;

@Controller
public class QuestionController {
    @Autowired
    QuestionDAO quesdao;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView unansweredQuestions(/*HttpServletRequest request, HttpServletResponse response,@ModelAttribute("question")Question question*/) {
        ModelAndView model = new ModelAndView("question");
        List<Question> qlist = quesdao.listUnansweredQuestion();
        model.addObject("list", qlist);
        System.out.println("index" + qlist.size());
		/*String ans=request.getParameter("answer");
		question.setAnswer(ans);
		System.out.println("answer"+ans);
		quesdao.saveAnswer(question);*/
        return model;
    }

    @RequestMapping(value = "/savedata", method = RequestMethod.POST)
    public ModelAndView saveAnswer(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView model = new ModelAndView("index");
        String ans = request.getParameter("answer");
        String question_id = request.getParameter("question_id");

      /*  Session session = this.sessionFactory.openSession();
        Transaction t = session.beginTransaction();
        Question question = (Question) session.get(Question.class, Long.valueOf(question_id));
        question.setAnswer(ans);
        session.persist(question);
        t.commit();//transaction is committed
        session.close();*/


		Question question=quesdao.getQuestionById(Long.valueOf(question_id));
		question.setAnswer(ans);
		//question.setStatus("Answered");
		quesdao.saveAnswer(question);
		System.out.println("answer-" + question);
        model.setViewName("redirect:/");
        return model;


    }
}