
 package com.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.domain.Category;

@Repository
public class CategoryDAO {
	@Autowired
    public SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory= sf;
	}
	public List<Category> listAllCategory()
	{
		Session session = this.sessionFactory.openSession();
		List<Category> lc=(List<Category>) session.get("",Category.class);
		return lc;
	}
	Category getCategoryById(Integer id)
	{
		Session session = this.sessionFactory.openSession();
		Category c=(Category) session.get(Category.class, id);
		return c;
		
	}
}
