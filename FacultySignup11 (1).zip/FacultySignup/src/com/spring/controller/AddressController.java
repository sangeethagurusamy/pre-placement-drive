package com.spring.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.AddressDAO;
import com.spring.domain.Address;

@SessionAttributes({ "user" })
@Controller
public class AddressController {
	@Autowired
	AddressDAO addressdao;
	Address add;
	@Autowired
	SessionFactory fac;
	@RequestMapping(value="/Faculty", method= RequestMethod.GET)

	public ModelAndView saveAddress(HttpServletRequest request, HttpServletResponse response , @ModelAttribute Address address)
	{
		ModelAndView model = new ModelAndView("Faculty");
		System.out.println("faculty"+fac);
		String street=request.getParameter("street_name");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		address.setCity(city);
		address.setStreet_name(street);
		address.setState(state);
		address.setCountry(country);
		addressdao.saveAddress(address);
		return model;
		
	}
}

