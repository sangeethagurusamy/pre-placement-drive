package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;



@SessionAttributes({ "user" })
@Controller
public class FacultyController {

	@RequestMapping(value="/FacultyHome",method= RequestMethod.GET)
	public ModelAndView saveAddress()
	{
		ModelAndView model = new ModelAndView("FacultyHome");
		System.out.println("home");
		return model;
		
	}
	
	
}
