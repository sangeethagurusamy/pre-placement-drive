package com.spring.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.ModelMap;

@Controller
public class HelloController {
	
	public HelloController() {
		System.out.println("nnnnnnnnnnnnnnnnnnnn");
	}
   @RequestMapping(value = "/",method = RequestMethod.GET)
   public String printHello() {
		System.out.println("wellocme");
      //org.springframework.web.servlet.DispatcherServlet
      return "Index";
   }
}