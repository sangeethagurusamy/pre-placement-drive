package com.spring.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.AddressDAO;
import com.spring.dao.FacultyDAO;
import com.spring.dao.UserDAO;
import com.spring.domain.Address;
import com.spring.domain.Faculty;
import com.spring.domain.Role;
import com.spring.domain.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
//@RequestMapping(value = "/User")
public class UserController {
	
	@Autowired
	FacultyDAO facultyDao;
	@Autowired
	UserDAO userDao;
	@Autowired
	AddressDAO addressdao;
	@Autowired
	SessionFactory fac;
	@ModelAttribute("user")
	   public User setUpUserForm() {
	      return new User();
	   }
	
	@RequestMapping(value = "/Address", method = RequestMethod.POST)
	public ModelAndView saveUser(HttpServletRequest request, HttpServletResponse response , HttpSession session,@ModelAttribute("user") User user) throws ParseException {
		ModelAndView model = new ModelAndView("Address");
		System.out.println("ddddddddddddd" + fac);

		/*String userid = request.getParameter("userId");
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String mobileNumber = request.getParameter("mobileNumber");
		String dob = request.getParameter("dob");
		String role = request.getParameter("role");
		String gender = request.getParameter("gender"); */
		user.setFirstName("sangeetha");
		/*user.setLastName(lname);
		user.setPassword(password);
		user.setEmail(email);
		user.setMobile(mobileNumber);
		String id=request.getParameter("id");*/
		//System.out.println(id);
		//user.setGender(gender);
		//userDao.saveUser(user);
		//System.out.println(id);
		//model.addObject("user_id",11);
		return model;
	}
	
	@RequestMapping(value = "/saveall")
	public ModelAndView saveAll(@ModelAttribute ("user")User users) {
		System.out.println(users.getFirstName());
		ModelAndView model = new ModelAndView("Address");
		return model;
	}


	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index() {
		ModelAndView model = new ModelAndView("Index");
		System.out.println("index");
		return model;
	}

}
