package com.spring.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.domain.Address;
@Component
public class AddressDAO
{
	public AddressDAO() {
		System.out.println("mmmmmmmmmmm");
			}
	@Autowired
    public SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory= sf;
	}
	public boolean saveAddress(Address addressIns	)
	{
		Session session = this.sessionFactory.openSession();
		if(session.save(addressIns)!=null)
		{
		return true;
		}
		return false;
	}

}
