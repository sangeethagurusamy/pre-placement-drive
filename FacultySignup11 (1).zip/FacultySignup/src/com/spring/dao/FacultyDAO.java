package com.spring.dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.domain.Faculty;

@Component
public class FacultyDAO {
	public FacultyDAO() {
System.out.println("vvvvvvvvvvvvvvvvvvv");
	}

	@Autowired
	public SessionFactory sessionFactory;
	//Session session = sessionFactory.getCurrentSession();

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	/*public List<Integer> valueId() {
		SQLQuery query = session.createSQLQuery("SELECT `AUTO_INCREMENT`FROM  INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'project'	AND   TABLE_NAME   = 'user'");
		List<Integer> res = query.list();
		return res;
	}*/
	
	
	public boolean saveFaculty(Faculty facultyIns) {
		Session session = this.sessionFactory.openSession();
		if (session.save(facultyIns) != null) {
			return true;
		}
		return false;

	}

	public void saveExperience(Faculty facultyIns) {
		Session session = this.sessionFactory.openSession();
		session.saveOrUpdate(facultyIns);

	}
}
