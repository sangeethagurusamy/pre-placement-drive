package com.spring.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.domain.Role;
@Component
public class RoleDAO {
	@Autowired
    public SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory= sf;
}
	Role getRoleByName(String roleName)
	{
		Session session = this.sessionFactory.openSession();
		Role r = (Role) session.get(Role.class, roleName);
		return r;
		
	}

}
