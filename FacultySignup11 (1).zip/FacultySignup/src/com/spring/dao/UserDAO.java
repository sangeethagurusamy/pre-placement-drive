package com.spring.dao;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.domain.Address;
import com.spring.domain.User;


@Service
public class UserDAO {
	@Autowired
    public SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory= sf;
	}
	public boolean saveUser(User user	)
	{
		Session session = this.sessionFactory.openSession();
		if(session.save(user)!=null)
		{
		return true;
		}
		return false;
	}


}