package com.spring.domain;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
//import org.hibernate.annotations.Entity; 
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component; 
@Entity 
@Table(name="faculty")
public class Faculty extends User {
	
	
	private Long experience;

	public Faculty(Long experience) {
		super();
		this.experience = experience;
	}

	public Long getExperience() {
		return experience;
	}
public Faculty()
{
	
}
	public void setExperience(Long experience) {
		this.experience = experience;
	}

}
