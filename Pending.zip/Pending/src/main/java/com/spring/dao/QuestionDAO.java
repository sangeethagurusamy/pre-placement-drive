package com.spring.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.domain.Question;
@Service
public class QuestionDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Question> getPendingAnswers()
	{
		Session session = sessionFactory.openSession();
		System.out.println("unanswer");
		Criteria cr = session.createCriteria(Question.class);
		cr.add(Restrictions.eq("status", "Answered"));
		List<Question> list = cr.list();
		return list;
		
		
	}

}
