	package com.spring.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;


@Entity  
@Table(name="senior")  
@PrimaryKeyJoinColumn(name="ID")  
public class Senior extends User{
	private String	name;
	private String	designation;
	private Integer	yearOfPassing;
	private String	department;
	public Senior()
	{
		
	}
	public Senior(String name, String designation, Integer yearOfPassing, String department) {
		super();
		this.name = name;
		this.designation = designation;
		this.yearOfPassing = yearOfPassing;
		this.department = department;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Integer getYearOfPassing() {
		return yearOfPassing;
	}
	public void setYearOfPassing(Integer yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}

}
